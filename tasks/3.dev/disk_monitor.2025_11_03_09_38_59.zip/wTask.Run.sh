#!/bin/bash
set -e

echo "`pwd`"
echo ${wtask_src_path}
disk_max=`expr ${wtask_disk_max} * 1024 * 1024`

dir_users=`echo ${wtask_dir_user} | tr '@@@' ' '`
for dir_user in ${dir_users};
do
    cd ${dir_user}
    echo "${dir_user} ..."
    du --max-depth=1 --threshold=${disk_max} | awk '{if($2!=".")print $1"\t"$2}'
done