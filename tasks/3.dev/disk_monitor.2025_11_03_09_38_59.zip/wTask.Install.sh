#!/bin/bash
set -e

echo "`pwd`"