#!/bin/bash
set -e

# wtask_disk_max=10
# wtask_cpu_max=1
# wtask_mem_max=1
# wtask_mem_kill=30
# ips="127.0.0.1\n111.123.123.123"

# disk
echo "disk ..."
df | awk -v th=${wtask_disk_max} '{gsub(/%/, "", $5);if($5+0>=th)print "disk warning:\t"$5"%\t"$6}'

# cpu
echo "cpu ..."
top -bn1 | head -10 | grep "Cpu(s)" | awk -v th=${wtask_cpu_max} '{if($9=="id,"&&100-$8>th)print "cpu warning: "100-$8}'

# mem
echo "mem ..."
top -bn1 | head -10 | grep "MiB Mem"| awk -v th=${wtask_mem_max} '{a=100-$6/$4*100;if(a>th)print "mem warning: "a}'

echo "mem_kill..."
v=$(top -bn1 | head -10 | grep "MiB Mem"| awk -v th=${wtask_mem_kill} '{a=100-$6/$4*100;if(a>th)print "mem_kill warning: "a}')
if [[ "$v" != "" ]]; then
    echo ${v}
    pid_data="`top -bn1 | head -8 | tail -1 | awk '{print $1"\t\t"$10"%\t"$12}'`"
    pid="`echo ${pid_data} | awk '{print $1}'`"
    exe="`echo ${pid_data} | awk '{print $3}'`"
    echo "kill ${pid} ${exe}"
    # kill ${pid}
fi

# ip
# echo ${ips}
for ip in ${ips//\\n/ };
do
    echo "IP ${ip} ..."
    v=$(ping -W 1 -c 5 ${ip} | grep "transmitted" | awk '{gsub(/%/, "", $6);if($6+0>50)print $6,$7,$8}')
    if [[ "$v" != "" ]]; then
        echo -e "IP warning: ${ip}\t\t${v}"
    fi
done