# Img to GIF

将批量PNG/JPG/JPEG图片转为GIF

## 作者

winter <winter_lonely@foxmail.com>
