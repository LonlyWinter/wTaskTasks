#!/bin/bash
set -e

# python
echo "Installing python ..."
bash micromamba.sh wtask_tool 3.12 4.2 numpy imageio

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_tool

micromamba install -y zip \
    -c defaults -c conda-forge -c bioconda -n wtask_bio
