#!/bin/bash
echo `pwd`