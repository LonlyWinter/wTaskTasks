# Zip Dir

将文件夹内的所有数据压缩为zip，方便下载数据


## 一、输入参数说明

## 1. 数据：`dir_zip`

需要压缩的文件夹数据

## 2. 参数：`link_to_file`

是否需要将快捷方式转换为文件


## 二、输出文件说明


## 三、任务作者

winter <winter_lonely@foxmail.com>
