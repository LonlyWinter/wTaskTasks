
# Wait CMD

等待其它程序完成后再运行命令

## 作者

winter <winter_lonely@foxmail.com>
