#!/bin/bash

while [ `ps aux | grep "${wtask_exe_wait}" | wc -l` -gt 1  ]
do
    echo "$(date '+%Y-%m-%d %H:%M:%S') waiting ..."
    sleep ${wtask_time_gap}s
done

echo "$(date '+%Y-%m-%d %H:%M:%S') Start"
eval ${wtask_cmd_run}
echo "$(date '+%Y-%m-%d %H:%M:%S') Done"
