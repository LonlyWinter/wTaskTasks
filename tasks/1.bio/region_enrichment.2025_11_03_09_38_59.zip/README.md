# Region Enrichment

使用regionR计算不同Region之间的富集程度


## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
