#!/bin/bash
set -e

env_name=${1}
python_version=${2}
r_version=${3}

if [ ! -n "${4}" ]
then 
    echo "Need env_name/python_version/python_packages" 
    exit 2
else 
    echo "Env ${env_name}, Python ${python_version}, R ${r_version}" 
fi 

# install micromamba
PROGRAM="micromamba"
if command -v "$PROGRAM" &> /dev/null; then
    echo "$PROGRAM installed"
else
    echo "$PROGRAM installing ..."
    if command -v "dnf" &> /dev/null; then
        dnf install -y tar bzip2 which gawk rsync gzip wget > /dev/null 2>&1
    else
        apt install -y tar bzip2 which gawk rsync gzip wget > /dev/null 2>&1
    fi
    # Computing artifact location
    case "$(uname)" in
    Linux)
        PLATFORM="linux" ;;
    Darwin)
        PLATFORM="osx" ;;
    *NT*)
        PLATFORM="win" ;;
    esac

    ARCH="$(uname -m)"
    case "$ARCH" in
        aarch64|ppc64le|arm64)
            ;;  # pass
        *)
        ARCH="64" ;;
    esac

    case "$PLATFORM-$ARCH" in
        linux-aarch64|linux-ppc64le|linux-64|osx-arm64|osx-64|win-64)
            ;;  # pass
        *)
        echo "Failed to detect your OS" >&2
        exit 1
        ;;
    esac
    
    cd /
    echo "Downloading micromamba: ${PLATFORM}-${ARCH}"
    curl -Ls https://micro.mamba.pm/api/micromamba/${PLATFORM}-${ARCH}/latest | tar -xvj bin/micromamba
    ./bin/micromamba shell init -s ${SHELL/\/bin\//} > /dev/null 2>&1
    if command -v "$PROGRAM" &> /dev/null; then
        echo "$PROGRAM installed"
    else
        echo "$PROGRAM installed error"
        exit 1
    fi
fi

# install env
if [ -z "`micromamba env list | grep ${env_name}`" ]; then
    echo "$PROGRAM ${env_name} installing python & R"
    micromamba create -y -n ${env_name} -c conda-forge -c defaults -c bioconda python=${python_version} r-base=${r_version} > /dev/null 2>&1
    
    eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
    micromamba activate ${env_name}

    echo "$PROGRAM ${env_name} installing python packages"
    python${python_version} -m pip install -i https://mirrors.westlake.edu.cn/pypi/simple requests ${@:4} > /dev/null 2>&1
fi
echo "$PROGRAM ${env_name} env installed"

