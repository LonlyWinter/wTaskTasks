# Region Signal Profile

计算region上面不同bigwig的信号值分布

## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
