# enrichment plot

根据富集分析结果，挑选需要的term画图


- 部分示例结果[文章链接](https://www.nature.com/articles/s41467-024-50551-2)

![Example](./doc/example.jpg)


## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
