# Region Specific WithRep

计算两类Region之间的区别，每类Region有多个重复


## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
