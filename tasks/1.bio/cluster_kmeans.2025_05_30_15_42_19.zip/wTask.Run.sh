#!/bin/bash
set -e

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_bio

python3.12 -c "import sys;sys.path.append(\"${wtask_src_path}\");from src import main;main()"