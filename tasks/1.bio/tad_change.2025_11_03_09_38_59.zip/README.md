# TAD Change

利用HiCExplorer结果，根据domain.bed计算TAD的变化：Unchanged、Separation、Fusion、EquilongShift、UnilateralShift、Resharp

## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
