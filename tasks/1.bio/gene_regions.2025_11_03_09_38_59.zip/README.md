# gene regions

获取基因对应的region

- Promoter
- GeneBody
- CorePromoter
- DistalRegion
- TSS

## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
