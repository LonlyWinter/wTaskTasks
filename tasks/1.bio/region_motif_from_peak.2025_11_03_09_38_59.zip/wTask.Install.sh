#!/bin/bash
set -e

# python
echo "Installing python ..."
bash micromamba.sh wtask_bio 3.12 4.4 numpy pandas matplotlib seaborn scipy scikit-learn adjustText beautifulsoup4 chardet umap-learn PyPDF2

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_bio

# R: edgeR Seurat ggplot2 readxl clusterProfiler regioneR DESeq2
Rscript -e "install.packages('BiocManager', repos='http://mirrors.tuna.tsinghua.edu.cn/CRAN/')"
Rscript -e "install.packages('ggplot2', repos='http://mirrors.tuna.tsinghua.edu.cn/CRAN/')"
Rscript -e "options(BioC_mirror='https://mirrors.westlake.edu.cn/bioconductor')" -e "BiocManager::install(c('edgeR', 'Seurat', 'readxl', 'clusterProfiler', 'regioneR', 'DESeq2'))"

# other
micromamba install -y \
    wget pigz \
    bowtie2 hisat2 macs3 homer\
    samtools bedtools deeptools sra-tools \
    ucsc-bedgraphtobigwig ucsc-bedclip ucsc-bigwigaverageoverbed \
    -c defaults -c conda-forge -c bioconda -n wtask_bio

# genome
echo "Building genome ..."
python3.12 -c "from genome import main;main()"

echo "done"