# Gene Venn

计算不同基因之间的交集，每个文件内的基因为一类，两两做交集


- 部分示例结果[文章链接](https://www.nature.com/articles/s41467-024-50551-2)

![Example](./doc/example.jpg)


## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
