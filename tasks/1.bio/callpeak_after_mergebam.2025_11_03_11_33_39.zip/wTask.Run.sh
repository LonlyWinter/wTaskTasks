#!/bin/bash
set -e

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_bio

dir_result="`pwd`"
[ -z ${wbio_task_num+x} ] && wbio_task_num="2"

file_bams=`echo ${wtask_file_bams} | tr '@@@' ' '`
samtools merge -@ ${wbio_task_num} -o ${dir_result}/${wtask_sample_name}.tmp.bam ${file_bams}
echo "11 samtools sort ..."
samtools sort -n -@ ${wbio_task_num} ${dir_result}/${wtask_sample_name}.tmp.bam > ${dir_result}/${wtask_sample_name}.bam

rm -rf ${dir_result}/${wtask_sample_name}.tmp.bam

# bam call peak
mkdir -p ${dir_result}/peak
mkdir -p ${dir_result}/log

echo "20 callpeak bam e3 ..."
macs3 -t ${dir_result}/${wtask_sample_name}.bam \
    -n ${dir_result}/peak/${wtask_sample_name}.e3 \
    -f BAM -g ${wtask_species} \
    --keep-dup all --nomodel \
    --shiftsize ${wtask_shiftsize} \
    -p 1e-3 > ${dir_result}/log/${wtask_sample_name}.e3.PeakCalling.log 2>&1

echo "28 callpeak bam e5 ..."
macs3 -t ${dir_result}/${wtask_sample_name}.bam \
    -n ${dir_result}/peak/${wtask_sample_name}.e5 \
    -f BAM -g ${wtask_species} \
    --keep-dup all --nomodel \
    --shiftsize ${wtask_shiftsize} \
    -p 1e-5 > ${dir_result}/log/${wtask_sample_name}.e5.PeakCalling.log 2>&1

echo "36 callpeak bam e7 ..."
macs3 -t ${dir_result}/${wtask_sample_name}.bam \
    -n ${dir_result}/peak/${wtask_sample_name}.e7 \
    -f BAM -g ${wtask_species} \
    --keep-dup all --nomodel \
    --shiftsize ${wtask_shiftsize} \
    -p 1e-7 > ${dir_result}/log/${wtask_sample_name}.e7.PeakCalling.log 2>&1

# bam to bw
echo "45 bam to bdg ..."
macs3 callpeak --SPMR -f BAMPE -t ${dir_result}/${wtask_sample_name}.bam --bdg -n ${dir_result}/${wtask_sample_name}

echo "48 bdg filter ..."
grep -v - ${dir_result}/${wtask_sample_name}_treat_pileup.bdg > ${dir_result}/${wtask_sample_name}.tmp.bdg
bedClip ${dir_result}/${wtask_sample_name}.tmp.bdg ${wtask_species} ${dir_result}/${wtask_sample_name}_treat_pileup.bdg
grep -v _ ${dir_result}/${wtask_sample_name}_treat_pileup.bdg | sort -k1,1 -k2,2n > ${dir_result}/${wtask_sample_name}.clean.bdg

echo "53 bdg to bw ..."
bedGraphToBigWig ${dir_result}/${wtask_sample_name}.clean.bdg ${wtask_species} ${dir_result}/${wtask_sample_name}.bw
rm -rf ${dir_result}/${wtask_sample_name}_*
rm -rf ${dir_result}/${wtask_sample_name}.tmp.bdg
rm -rf ${dir_result}/${wtask_sample_name}.clean.bdg