# CallPeak After MergeBam

将Bam文件Merge起来后，重新call peak

## 一、输入参数说明

## 二、输出文件说明

## 三、任务作者

winter <winter_lonely@foxmail.com>
