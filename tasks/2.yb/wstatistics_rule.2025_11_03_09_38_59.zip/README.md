# wStatistics rule

通用规则预筛选

[wStatistics平台链接](https://gitee.com/winter-lonely/wstatistics_install)

## 作者

winter <winter_lonely@foxmail.com>
