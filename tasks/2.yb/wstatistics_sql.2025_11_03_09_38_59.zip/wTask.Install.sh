#!/bin/bash
set -e

echo "https://gitee.com/winter-lonely/wstatistics_install"
# wtask_wstatistics

rpm -i oracle-instantclient-basic-21.7.0.0.0-1.el8.x86_64.rpm

# python
echo "Installing python ..."
bash micromamba.sh wtask_wstatistics 3.12 4.2 openpyxl cx_Oracle python-dateutil DBUtils PyMySQL SQLAlchemy numpy pandas

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_wstatistics
