#!/bin/bash
set -e

# python
echo "Installing python ..."
bash micromamba.sh wtask_spider 3.12 4.2 beautifulsoup4

eval "$(micromamba shell hook --shell ${SHELL/\/bin\//})"
micromamba activate wtask_spider

echo "done"